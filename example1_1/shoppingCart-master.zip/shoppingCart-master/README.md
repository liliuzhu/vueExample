# shoppingCart
vue2.0购物车组件开发

基于vue2.0开发
vue-resource
